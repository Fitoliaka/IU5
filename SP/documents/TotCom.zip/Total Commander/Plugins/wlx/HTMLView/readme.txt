HTMLView 1.2.6 lister-plugin for Total Commander 5.x+ for Win32
Freeware and open-source
http://sites.google.com/site/htmlview/


Description
IE-based file viewer plugin for Total Commander.
The plugin uses MS WebBrowser control to view html documents.


Installation
* Open wlx_htmlview_x.x.rar file in Total Commander
* Choose directory to install 
* Adjust position of HTMLView in the plugins list
* Restart the Total Commander


Manual installation
* Copy HTMLView.wlx and HTMLView.ini files into your Total Commander plugins directory 
* Add the following line to [ListerPlugins] section in the wincmd.ini file:
   0=C:\wincmd\plugins\HTMLView.wlx
   Be sure to substitute actual path to the HTMLView.wlx file. 
* Restart the Total Commander.
