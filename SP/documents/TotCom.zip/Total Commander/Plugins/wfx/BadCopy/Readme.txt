Badcopy 1.0.0.4 - FS plugin for Total Commander
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
(c) Hramov Eugene hram-ov@mail.ru

http://hram-tc.narod.ru

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Description:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Copies files from bad CDs / DVD of disks, and also with bad HDD. 
Reads out a file parts, and those parts that were not read fills in zero. 
For disks with films it is not critical also films after that it will be possible to look.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
Installation:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Unzip the archive to any directory

2. Launch Total Commander and choose Configuration -> Options -> Operation -> FS-Plugins

3. Click "Add"

4. Go to the directory where the archive was unzipped, and select badcopy.wfx

5. Click OK.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Usage:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Under Total Commander, access 'My Network places'

2. Double click on 'badcopy'

2. Choose the carrier (folder, file, files) with which it is necessary to count the information

3. Pressed F5 fo copy


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Version:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1.0.0.1 - first release