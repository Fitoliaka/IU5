"MSIE Cache Browser" plugin for Total Commander
-----------------------------------------------
This file-system plugin allows to browse Microsoft Internet Explorer
cache ("Temporary Internet Files" folder contents). Unlike Explorer,
plugin shows cache in structured form: domains list, sites list for
every domain, URLs list for every site.

- Cache entries can be opened and deleted. Opening of an entry will
  open it in MSIE in offline mode;
- To reread cache open "Reread cache" pseudo-file.
- To copy URLs to Clipboard, copy entry(es) to "c".


Installation
------------
With TC 6.5+: just open archive and TC will install plugin automatically.
Or - installation by hand: unpack archive to some folder and install like
any other FS plugin: go to Options -> Plugins -> File-system plugins ->
Add, then select IECache.wfx file.


Copyright (c) Alexey Torgashin
http://atorg.net.ru
http://totalcmd.net/plugring/msie_cache.html
