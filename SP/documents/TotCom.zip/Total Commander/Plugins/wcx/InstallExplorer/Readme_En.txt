========================================================================
InstallExplorer - archive plugin for TotalCommander
========================================================================

Version 0.9.1

This plugin is a remake of an old plugin by an unknown author called
"InstallExporer Port", which uses the original InstallExplorer FAR plugin �
by Sergei Wanin. The plugin enables you to browse and extract the contents
of .exe and .msi files, created by the following installers: Wise Installer,
Vise Installer, Inno Setup, Gentee Installer, numerous InstallShield
versions, NullSoft Installer versions 1.1o and up, SetupFactory, Eschalon
Installer, and Windows Installer (MSI). My plugin is more stable, than the
old port, and unpacks all files correctly. The package contains the original
InstallExplorer FAR plugin by Sergei Wanin.

Installation is automatic (associated with .msi file extension).
To open .exe files use <Ctrl+PageDown> combination.
Attention: This plugin is slow when opening large files!

========================================================================
